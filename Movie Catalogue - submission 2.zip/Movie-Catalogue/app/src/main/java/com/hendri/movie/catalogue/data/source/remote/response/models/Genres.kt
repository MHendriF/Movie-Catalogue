package com.hendri.movie.catalogue.data.source.remote.response.models

data class Genres(
    val id: Int,
    val name: String
)