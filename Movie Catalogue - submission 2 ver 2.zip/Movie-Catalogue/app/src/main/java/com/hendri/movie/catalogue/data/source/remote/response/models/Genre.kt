package com.hendri.movie.catalogue.data.source.remote.response.models

data class Genre(
    val id: Int,
    val name: String
)