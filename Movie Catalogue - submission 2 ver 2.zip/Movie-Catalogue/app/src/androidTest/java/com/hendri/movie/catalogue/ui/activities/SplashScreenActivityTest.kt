package com.hendri.movie.catalogue.ui.activities

import androidx.test.ext.junit.rules.ActivityScenarioRule
import org.junit.Rule
import org.junit.Test

class SplashScreenActivityTest {
    @get:Rule
    var activity = ActivityScenarioRule(SplashScreenActivity::class.java)

    @Test
    fun loadSplash() {}
}